Vou implementar os 6 fixes em sequência, sem alterar o design system.

## Fix 1 — Cache de motivação no Supabase
- Migration: adicionar `motivation_cache` (text) e `motivation_cached_at` (timestamptz) em `profiles`
- Refatorar `dashboard.tsx` para ler/escrever cache em `profiles` (TTL 6h)
- Remover todos os `localStorage` relacionados a `ls_motivation`

## Fix 2 — Reports completo
Reescrever `reports.tsx` com:
- 4 metric cards (taxa de conclusão, max streak, humor médio 7d, score)
- AreaChart: tarefas concluídas por dia (30d)
- BarChart horizontal: top 5 hábitos por consistência
- ComposedChart: humor vs tarefas (14d)
- Bloco de insights automáticos (até 3 bullets condicionais)

## Fix 3 — Settings completo
Reescrever `settings.tsx` em 4 seções:
- Perfil (nome, objetivo, peak_hour) → migration adiciona `peak_hour` em profiles
- Preferências (toggles + tema) → migration adiciona `auto_rollover` em profiles
- Integrações (Google Calendar status, conectar/desconectar)
- Dados (exportar JSON, sair, excluir conta com AlertDialog)

## Fix 4 — Onboarding lazy disclosure
Refatorar `onboarding.tsx`:
- Passo 1 (obrig): nome + objetivo
- Passo 2 (obrig): energia
- Passo 3 (opcional): horários — botão "Pular"
- Passo 4 (opcional): rotina — botão "Pular"
- `skipToEnd` marca onboarded e vai pro dashboard

## Fix 5 — IA com memória + insights preventivos
- Migration: criar tabela `ai_memory` + tabela `notifications` (user_id, type, title, body, read, created_at) com RLS
- `/api/chat`: após resposta, fazer 2ª chamada para extrair fatos → upsert em `ai_memory`
- `/api/chat`: injetar últimas 10 memórias no system prompt
- Novo `/api/analyze-patterns.ts` server route: detecta 3 padrões e insere notificações (sem duplicar)
- Dashboard: chamar analyze-patterns silenciosamente no mount
- Header em `_authenticated.tsx`: sino com badge, popover de 5 últimas, "marcar todas como lidas", Realtime

## Fix 6 — Testes Vitest
- Instalar vitest + testing-library + jsdom
- Criar `vitest.config.ts`
- Extrair `greeting()`, `productivityScore()`, `filterRolloverTasks()`, `weekData()` para `src/lib/utils.ts` (ou novo arquivo) caso ainda não estejam isolados
- Criar `src/__tests__/utils.test.ts` com 4 testes
- Adicionar script `test` no package.json

## Ordem de execução
1. Migrations (todas em uma) — profiles colunas + ai_memory + notifications
2. Fix 1 (dashboard motivação)
3. Fix 2 (reports)
4. Fix 3 (settings)
5. Fix 4 (onboarding)
6. Fix 5 (chat memória + analyze-patterns + sino)
7. Fix 6 (testes)

Confirma que posso começar pelas migrations?
