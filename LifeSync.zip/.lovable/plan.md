São 15 funcionalidades grandes. Entregar tudo num único push gera código frágil e difícil de revisar. Proponho dividir em 4 fases incrementais — cada fase é entregável e funcional sozinha. Confirme o plano e eu começo pela Fase 1 imediatamente.

## Fase 1 — Núcleo Inteligente (base para o resto)
- **Metas** (`/_authenticated/goals`): tabela `goals` (title, type diaria/semanal/mensal, target, progress, period_start/end), CRUD, barras animadas, histórico.
- **Mood Tracker**: tabela `moods` (mood enum, note, created_at). Widget no dashboard + página com gráfico de linha (humor x dia) e correlação com tarefas concluídas.
- **Onboarding inteligente** (`/onboarding`): wizard 4 passos (objetivo, horários disponíveis, rotina atual, energia). Ao final chama `/api/chat` com prompt estruturado pedindo JSON → cria tarefas e hábitos iniciais. Flag `onboarded` no profile.
- **Frases motivacionais**: card no dashboard com frase gerada via Lovable AI usando contexto (tarefas concluídas hoje vs ontem, streak, mood). Cache 6h.

## Fase 2 — Calendário + Prioridade IA
- **Calendário** (`/_authenticated/calendar`): views diária / semanal / mensal usando `react-big-calendar` ou grid custom. Coluna `due_date` + `time` já existe em tasks. Drag-and-drop com `@dnd-kit/core` (já flexível, sem dep de react-dnd). Detecção de conflito client-side.
- **IA sugere horários livres**: botão "Reorganizar dia" → server fn agrega tarefas + energia + horários e devolve nova ordem/horários.
- **Prioridade inteligente**: cron leve client-side (ao abrir dashboard) aciona server fn `recalc-priorities` que ajusta `priority` com base em `due_date` próximo, atrasos, etc.

## Fase 3 — IA Preventiva, Insights, Memória
- **Página Insights** (`/_authenticated/insights`): heatmap dias x horas (Recharts), top hábitos consistentes, melhor horário, evolução semanal — tudo derivado de `tasks` + `habit_completions` + `energy_logs` + `moods`.
- **IA com memória**: tabela `ai_memory` (key, value, updated_at) — server fn extrai fatos da conversa e armazena ("usuário rende mais de manhã"). System prompt do `/api/chat` injeta memórias relevantes.
- **IA preventiva**: server fn `analyze-patterns` roda ao abrir o app; se detectar sobrecarga (>8 tarefas hoje) ou atrasos repetidos, cria notificação inteligente.
- **Notificações inteligentes**: tabela `notifications` (title, body, type, read, created_at) + sino no header com dropdown. Realtime via Supabase channel.

## Fase 4 — Polish & Premium UX
- **Command Palette (Ctrl+K)**: usar `cmdk` (já parte do shadcn `command.tsx`) — modal global com busca em tarefas, hábitos, metas, navegação, ações ("nova tarefa", "abrir IA").
- **Pesquisa global**: mesmo modal, aba "tudo" agregando os recursos.
- **Templates prontos**: tabela `templates` (system + user-owned) com seeds (estudos, fitness, trabalho, finanças). Tela `/_authenticated/templates` com importar/duplicar.
- **Modo Offline**: registrar service worker via `vite-plugin-pwa`, cache de rotas auth + IndexedDB para fila de mutações; banner "offline" + sync ao voltar.
- **Multi-device**: já garantido pelo Supabase realtime + sessão persistente; só revisar e adicionar status "sincronizado" no header.

## Detalhes técnicos
- Migrations: `goals`, `moods`, `notifications`, `ai_memory`, `templates`, `template_items`, coluna `onboarded` em `profiles`. Todas com RLS `auth.uid() = user_id`.
- Server fns/rotas novas em `src/routes/api/`: `chat` (já existe, será expandido com memória), `analyze-patterns`, `recalc-priorities`, `generate-routine`, `motivation`.
- Drag-drop: `@dnd-kit/core` + `@dnd-kit/sortable`.
- Calendário: grid próprio leve (evita peso de libs grandes).
- PWA: `vite-plugin-pwa` com `registerType: autoUpdate` + Workbox runtime caching.
- Command palette: `cmdk` (já presente em `components/ui/command.tsx`).

## Pergunta antes de começar
Confirma esse faseamento? Posso:
- **(A)** Executar tudo agora em 4 commits sequenciais (longo, ~30min de geração, alto risco de erros que vou ter que iterar).
- **(B)** Executar **só a Fase 1** agora, validar com você, e seguir para Fase 2 na próxima mensagem (recomendado).
- **(C)** Mudar a ordem / cortar alguma feature.

Responda **A**, **B** ou **C** (com ajustes) e eu começo.