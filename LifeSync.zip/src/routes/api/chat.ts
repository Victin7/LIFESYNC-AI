import "@tanstack/react-start";
import { createFileRoute } from "@tanstack/react-router";

const LOVABLE_AI_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";

const SYSTEM_PROMPT = `Você é o assistente inteligente do LifeSync AI, especializado em produtividade, organização, hábitos e gerenciamento de rotina. Sua função é ajudar o usuário a organizar tarefas, melhorar produtividade, reduzir procrastinação e criar rotinas inteligentes baseadas nos dados reais do sistema.

Diretrizes:
- Responda em português do Brasil, de forma clara, motivadora e prática.
- Use markdown: **negrito**, listas, títulos curtos quando útil, blocos de código quando fizer sentido.
- Quando sugerir uma rotina, use lista com horários (HH:MM).
- Adapte o conselho ao nível de energia (cansado, normal, produtivo).
- Use os dados reais (tarefas, hábitos, metas, humor) que aparecem no contexto. Não invente dados.
- Seja conciso. Vá direto ao ponto. Evite preâmbulos longos.`;

type Ctx = {
  energy?: string;
  mood?: string;
  tasks?: { title: string; priority?: string; time?: string | null; done?: boolean; category?: string | null }[];
  habits?: { name: string; streak?: number }[];
  goals?: { title: string; progress?: number; target?: number; type?: string }[];
};

function buildContext(ctx: Ctx): string {
  const parts: string[] = [];
  if (ctx.energy) parts.push(`Energia atual: ${ctx.energy}`);
  if (ctx.mood) parts.push(`Humor recente: ${ctx.mood}`);
  if (ctx.tasks?.length) {
    const open = ctx.tasks.filter((t) => !t.done).slice(0, 15);
    const done = ctx.tasks.filter((t) => t.done).length;
    parts.push(
      `Tarefas abertas (${open.length}, ${done} concluídas hoje):\n` +
        open.map((t) => `- ${t.title} | prioridade=${t.priority ?? "media"}${t.time ? ` | ${t.time}` : ""}${t.category ? ` | ${t.category}` : ""}`).join("\n"),
    );
  }
  if (ctx.habits?.length) {
    parts.push(`Hábitos (${ctx.habits.length}):\n` + ctx.habits.slice(0, 10).map((h) => `- ${h.name}${h.streak ? ` (streak ${h.streak})` : ""}`).join("\n"));
  }
  if (ctx.goals?.length) {
    parts.push(`Metas ativas:\n` + ctx.goals.slice(0, 10).map((g) => `- ${g.title} (${g.progress ?? 0}/${g.target ?? 1}${g.type ? `, ${g.type}` : ""})`).join("\n"));
  }
  return parts.length ? `\n\n--- DADOS DO USUÁRIO ---\n${parts.join("\n\n")}\n--- FIM DOS DADOS ---` : "";
}

type AIMessage = { role: "system" | "user" | "assistant"; content: string };

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        try {
          const apiKey = process.env.LOVABLE_API_KEY;
          if (!apiKey) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

          const body = (await request.json()) as { messages?: AIMessage[]; context?: Ctx };
          const messages = Array.isArray(body.messages) ? body.messages : [];
          if (!messages.length) return new Response("messages required", { status: 400 });

          const ctxBlock = buildContext(body.context ?? {});

          const upstream = await fetch(LOVABLE_AI_URL, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Lovable-API-Key": apiKey,
              "X-Lovable-AIG-SDK": "fetch",
            },
            body: JSON.stringify({
              model: "google/gemini-2.5-pro",
              stream: true,
              messages: [
                { role: "system", content: SYSTEM_PROMPT + ctxBlock },
                ...messages.slice(-20),
              ],
            }),
          });

          if (!upstream.ok || !upstream.body) {
            const text = await upstream.text().catch(() => "");
            if (upstream.status === 429) return new Response("Limite de requisições atingido. Tente em instantes.", { status: 429 });
            if (upstream.status === 402) return new Response("Créditos de IA esgotados.", { status: 402 });
            return new Response(text || "Erro IA", { status: upstream.status });
          }

          // Parse SSE from gateway, re-emit only text deltas as plain text stream
          const stream = new ReadableStream<Uint8Array>({
            async start(controller) {
              const reader = upstream.body!.getReader();
              const decoder = new TextDecoder();
              const encoder = new TextEncoder();
              let buf = "";
              try {
                while (true) {
                  const { done, value } = await reader.read();
                  if (done) break;
                  buf += decoder.decode(value, { stream: true });
                  const lines = buf.split("\n");
                  buf = lines.pop() ?? "";
                  for (const line of lines) {
                    const l = line.trim();
                    if (!l.startsWith("data:")) continue;
                    const data = l.slice(5).trim();
                    if (!data || data === "[DONE]") continue;
                    try {
                      const json = JSON.parse(data);
                      const delta = json.choices?.[0]?.delta?.content;
                      if (delta) controller.enqueue(encoder.encode(delta));
                    } catch { /* skip */ }
                  }
                }
              } catch (e) {
                controller.error(e);
                return;
              }
              controller.close();
            },
          });

          return new Response(stream, {
            status: 200,
            headers: {
              "Content-Type": "text/plain; charset=utf-8",
              "Cache-Control": "no-cache, no-transform",
              "X-Accel-Buffering": "no",
            },
          });
        } catch (e) {
          console.error("[/api/chat] error", e);
          return new Response("Erro interno", { status: 500 });
        }
      },
    },
  },
});
