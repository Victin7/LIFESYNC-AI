import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { useProfile } from "@/lib/db";
import { useAuth } from "@/contexts/AuthContext";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Configurações — LifeSync AI" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const { signOut } = useAuth();
  const nav = useNavigate();
  const { profile, update } = useProfile();

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Configurações</h1>
        <p className="text-muted-foreground mt-1">Personalize sua experiência.</p>
      </div>

      <div className="rounded-2xl border border-border bg-card-grad p-6 space-y-4">
        <Toggle label="Notificações" desc="Receba lembretes de tarefas e hábitos."
          value={profile?.notifications ?? true}
          onChange={(v) => { update({ notifications: v }); toast.success("Salvo"); }} />
        <Toggle label="Sugestões da IA" desc="Permitir que a IA reorganize sua rotina."
          value={profile?.ai_suggestions ?? true}
          onChange={(v) => { update({ ai_suggestions: v }); toast.success("Salvo"); }} />
      </div>

      <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-6">
        <div className="font-medium text-destructive">Sair da conta</div>
        <p className="text-sm text-muted-foreground mt-1">Você precisará entrar novamente.</p>
        <button onClick={async () => { await signOut(); nav({ to: "/" }); }}
          className="mt-3 px-4 py-2 rounded-xl border border-destructive/40 text-destructive hover:bg-destructive/10">
          Sair
        </button>
      </div>
    </div>
  );
}

function Toggle({ label, desc, value, onChange }: { label: string; desc: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs text-muted-foreground">{desc}</div>
      </div>
      <button onClick={() => onChange(!value)}
        className={`w-11 h-6 rounded-full relative transition-colors ${value ? "bg-primary" : "bg-border"}`}>
        <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-background transition-transform ${value ? "translate-x-5" : ""}`} />
      </button>
    </div>
  );
}
