import { createFileRoute } from "@tanstack/react-router";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar } from "recharts";
import { useTasks, useHabits } from "@/lib/db";

export const Route = createFileRoute("/_authenticated/reports")({
  head: () => ({ meta: [{ title: "Relatórios — LifeSync AI" }] }),
  component: Reports,
});

function Reports() {
  const { tasks } = useTasks();
  const { habits, completions } = useHabits();

  const last7 = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(); d.setDate(d.getDate() - (6 - i));
    const iso = d.toISOString().slice(0, 10);
    const label = d.toLocaleDateString("pt-BR", { weekday: "short" });
    const habitsDone = completions.filter((c) => c.completed_on === iso).length;
    return { d: label, h: habitsDone, v: habitsDone * 15 };
  });

  const done = tasks.filter((t) => t.done).length;
  const pct = tasks.length ? Math.round((done / tasks.length) * 100) : 0;

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Relatórios</h1>
        <p className="text-muted-foreground mt-1">Acompanhe sua produtividade.</p>
      </div>

      <div className="grid sm:grid-cols-3 gap-4">
        <Card label="Conclusão" value={`${pct}%`} />
        <Card label="Hábitos ativos" value={String(habits.length)} />
        <Card label="Concluídos (7d)" value={String(completions.length)} />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="rounded-2xl border border-border bg-card-grad p-5">
          <div className="text-sm font-medium mb-2">Tempo de foco semanal</div>
          <div className="h-64">
            <ResponsiveContainer>
              <AreaChart data={last7}>
                <defs>
                  <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.62 0.18 258)" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="oklch(0.62 0.18 258)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.41 0.04 258)" />
                <XAxis dataKey="d" stroke="oklch(0.6 0.025 250)" fontSize={12} />
                <YAxis stroke="oklch(0.6 0.025 250)" fontSize={12} />
                <Tooltip contentStyle={{ background: "oklch(0.275 0.039 263)", border: "1px solid oklch(0.41 0.04 258)", borderRadius: 12 }} />
                <Area dataKey="v" stroke="oklch(0.62 0.18 258)" strokeWidth={2} fill="url(#g)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card-grad p-5">
          <div className="text-sm font-medium mb-2">Hábitos por dia</div>
          <div className="h-64">
            <ResponsiveContainer>
              <BarChart data={last7}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.41 0.04 258)" />
                <XAxis dataKey="d" stroke="oklch(0.6 0.025 250)" fontSize={12} />
                <YAxis stroke="oklch(0.6 0.025 250)" fontSize={12} />
                <Tooltip contentStyle={{ background: "oklch(0.275 0.039 263)", border: "1px solid oklch(0.41 0.04 258)", borderRadius: 12 }} />
                <Bar dataKey="h" fill="oklch(0.62 0.18 258)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}

function Card({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card-grad p-5">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-2 text-3xl font-bold">{value}</div>
    </div>
  );
}
