import { useState } from "react";
import { toast } from "sonner";
import { lovable } from "@/integrations/lovable";

export function GoogleButton({ label = "Continuar com Google", onSuccess }: { label?: string; onSuccess?: () => void }) {
  const [loading, setLoading] = useState(false);
  const click = async () => {
    setLoading(true);
    try {
      const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/dashboard" });
      if (result.error) {
        toast.error("Falha no login com Google", { description: String(result.error.message ?? result.error) });
        setLoading(false);
        return;
      }
      if (result.redirected) return;
      onSuccess?.();
    } catch (e) {
      toast.error("Erro ao iniciar login Google");
      setLoading(false);
    }
  };
  return (
    <button onClick={click} disabled={loading} type="button"
      className="w-full inline-flex items-center justify-center gap-3 px-4 py-2.5 rounded-xl border border-border bg-card hover:bg-card-hover transition-colors text-sm font-medium disabled:opacity-60">
      <svg className="w-4 h-4" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.4 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.6 6.1 29.6 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.2-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16 19 13 24 13c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.6 6.1 29.6 4 24 4 16.3 4 9.7 8.4 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.5 0 10.4-2.1 14.1-5.5l-6.5-5.5C29.5 34.7 26.9 36 24 36c-5.3 0-9.7-3.6-11.3-8.5l-6.6 5.1C9.6 39.5 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.3-4.2 5.6l6.5 5.5C40.3 36.7 44 31 44 24c0-1.2-.1-2.4-.4-3.5z"/></svg>
      {loading ? "Entrando..." : label}
    </button>
  );
}
